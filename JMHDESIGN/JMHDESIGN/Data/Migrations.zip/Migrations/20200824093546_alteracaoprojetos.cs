﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace JMHDESIGN.Data.Migrations
{
    public partial class alteracaoprojetos : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Funcionarios_Clientes_ClientesFK",
                table: "Funcionarios");

            migrationBuilder.DropIndex(
                name: "IX_Funcionarios_ClientesFK",
                table: "Funcionarios");

            migrationBuilder.DropColumn(
                name: "ClientesFK",
                table: "Funcionarios");

            migrationBuilder.AddColumn<int>(
                name: "ClientesIDcliente",
                table: "Funcionarios",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ProjetosClientes",
                columns: table => new
                {
                    IDprojcliente = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    IDprojFK = table.Column<int>(nullable: false),
                    IDproj1 = table.Column<int>(nullable: true),
                    IDclienteFK = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ProjetosClientes", x => x.IDprojcliente);
                    table.ForeignKey(
                        name: "FK_ProjetosClientes_Clientes_IDclienteFK",
                        column: x => x.IDclienteFK,
                        principalTable: "Clientes",
                        principalColumn: "IDcliente",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_ProjetosClientes_Funcionarios_IDproj1",
                        column: x => x.IDproj1,
                        principalTable: "Funcionarios",
                        principalColumn: "IDproj",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "c",
                column: "ConcurrencyStamp",
                value: "5dd76611-5d01-40f8-afe5-579514850b8e");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f",
                column: "ConcurrencyStamp",
                value: "1dbf1555-12ef-43b3-bc1d-63bc03837c92");

            migrationBuilder.CreateIndex(
                name: "IX_Funcionarios_ClientesIDcliente",
                table: "Funcionarios",
                column: "ClientesIDcliente");

            migrationBuilder.CreateIndex(
                name: "IX_ProjetosClientes_IDclienteFK",
                table: "ProjetosClientes",
                column: "IDclienteFK");

            migrationBuilder.CreateIndex(
                name: "IX_ProjetosClientes_IDproj1",
                table: "ProjetosClientes",
                column: "IDproj1");

            migrationBuilder.AddForeignKey(
                name: "FK_Funcionarios_Clientes_ClientesIDcliente",
                table: "Funcionarios",
                column: "ClientesIDcliente",
                principalTable: "Clientes",
                principalColumn: "IDcliente",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Funcionarios_Clientes_ClientesIDcliente",
                table: "Funcionarios");

            migrationBuilder.DropTable(
                name: "ProjetosClientes");

            migrationBuilder.DropIndex(
                name: "IX_Funcionarios_ClientesIDcliente",
                table: "Funcionarios");

            migrationBuilder.DropColumn(
                name: "ClientesIDcliente",
                table: "Funcionarios");

            migrationBuilder.AddColumn<int>(
                name: "ClientesFK",
                table: "Funcionarios",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "c",
                column: "ConcurrencyStamp",
                value: "5f505365-76c3-4eb2-9970-27d254defa87");

            migrationBuilder.UpdateData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "f",
                column: "ConcurrencyStamp",
                value: "ac0acf32-3ff6-421d-8ced-cbd698c9ed65");

            migrationBuilder.CreateIndex(
                name: "IX_Funcionarios_ClientesFK",
                table: "Funcionarios",
                column: "ClientesFK");

            migrationBuilder.AddForeignKey(
                name: "FK_Funcionarios_Clientes_ClientesFK",
                table: "Funcionarios",
                column: "ClientesFK",
                principalTable: "Clientes",
                principalColumn: "IDcliente",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
